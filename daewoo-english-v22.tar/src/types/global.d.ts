interface Window {
  __themeInit?: boolean
}
